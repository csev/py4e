Tue Jul 20 15:11:40 PDT 2010

Hello - these slides go with the first 10 chapters that go with
my "Python for Informatics: Exploring Information" www.py4inf.com

They are copyright Creative Commons Attribution.  If you use these slides,
please keep the second slide in each presentation as a copyright.

You do not need to keep the "Open Michigan" background for the slides - 
but please include all people's names from that second slides and 
add your own name as you make changes to the slides and 
redistribute your modified slides.

If you have any questions, please feel free to contact me 
at csev@umich.edu

/Chuck Severance
www.dr-chuck.com

