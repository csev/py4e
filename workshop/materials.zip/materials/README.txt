Python and Data Workshop
------------------------

This is a simple workshop that quickly flies through Python, Database, and 
HTTP scraping to expose students to a wide range of Python capabilities
when dealing with large, complex or unstructured data sets.

This goes along with the following sites:

http://www.pythonlearn.com/

http://online.dr-chuck.com/

-- Charles Severance
www.dr-chuck.com
Mon May 20 23:20:59 EDT 2013
